const { User, Doctor, Patient } = require('../models/user');


const updateDoctorProfile = async (req, res) => {
    const { birthDate, email, phone, expertise, specialty } = req.body;


    if (!email || !phone || !expertise || !specialty) {
        return res.status(400).json({ message: 'Email, phone, expertise, and specialty are required' });
    }

    try {
   
        const existingUser = await User.findOne({ email });
        if (existingUser && existingUser._id.toString() !== req.user.id) {
            return res.status(400).json({ message: 'Email already exists' });
        }

       
        const updatedUser = await User.findByIdAndUpdate(
            req.user.id,
            { birthDate, email, phone, expertise, specialty  },
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        const updatedDoctor = await Doctor.findOneAndUpdate(
            { user: req.user.id },
            { expertise, specialty },
            { new: true }
        );

        if (!updatedDoctor) {
            return res.status(404).json({ message: 'Doctor not found' });
        }

        res.status(200).json({ 
            message: 'Doctor profile updated successfully', 
            updatedUser, 
            updatedDoctor 
        });
    } catch (error) {
        res.status(500).json({ error: 'Error updating doctor profile: ' + error.message });
    }
};

// Get all patients linked to this doctor
const getAllPatientsForDoctor = async (req, res) => {
    try {
        // Find the doctor by user ID
        const doctor = await Doctor.findOne({ user: req.user.id });
        if (!doctor) {
            return res.status(404).json({ message: 'Doctor not found' });
        }

        // Get all patients linked to this doctor using the doctor's ID
        const patients = await Patient.find({ doctor: doctor._id }).populate('user');
        
        if (!patients || patients.length === 0) {
            return res.status(404).json({ message: 'No patients found for this doctor' });
        }

        res.status(200).json(patients);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching patients: ' + error.message });
    }
};


const getPatientById = async (req, res) => {
    const { patientId } = req.params; // Retrieve the patient's ID from the request parameters

    try {
        const patient = await Patient.findById(patientId).populate('user');
        if (!patient) {
            return res.status(404).json({ message: 'Patient not found' });
        }

        res.status(200).json(patient);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching patient by ID: ' + error.message });
    }
};

module.exports = {
    updateDoctorProfile,
    getAllPatientsForDoctor,
    getPatientById
};