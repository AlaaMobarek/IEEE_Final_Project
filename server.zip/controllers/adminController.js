const { User, Doctor, Patient } = require('../models/user');


const addDoctor = async (req, res) => {
    const { name, email, phone, expertise, specialty, password, adminId } = req.body;

    if (!email || !name || !phone || !expertise || !specialty || !password || !adminId) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can add doctors.' });
        }

        const existingDoctor = await User.findOne({ email });
        if (existingDoctor) {
            return res.status(400).json({ message: 'Doctor already exists' });
        }

        const newDoctorUser = new User({
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            password: req.body.password,
            role: req.body.role,
            expertise: req.body.expertise,
            specialty: req.body.specialty,
            birthDate: req.body.birthDate,
            gender: req.body.gender,
            age: req.body.age,
            adminId: req.body.adminId,
        });

        const savedUser=await newDoctorUser.save();


        const newDoctor = new Doctor({
            user: savedUser._id,
            expertise,
            specialty
        });

        await newDoctor.save();

        res.status(201).json({ message: 'Doctor added successfully', doctor: newDoctor });
    } catch (error) {
        console.error('Error adding doctor:', error);
        res.status(500).json({ error: 'Error adding doctor: ' + error.message });
    }
};

const retireDoctor = async (req, res) => {
    const { adminId, doctorId } = req.body;


    try {
        console.log('Doctor ID from request:', doctorId);
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can retire doctors.' });
        }

        const doctor1 = await Doctor.findOne({ user: doctorId });
console.log('Doctor from database:', doctor1);

        const doctor = await Doctor.findOneAndUpdate(
            { user: doctorId },
            { isRetired: true },
            { new: true }
        );

        if (!doctor) {
            console.log(doctor.role);
            console.log(doctor);
            return res.status(404).json({ message: 'Doctor not found' });
        }

        const updatedUser = await User.findByIdAndUpdate(
            doctorId,
            { isRetired: true }, // Add isRetired field to the User model
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: 'Doctor not found in the User collection' });
        }

        res.status(200).json({ message: 'Doctor retired successfully', doctor });
    } catch (error) {
        res.status(500).json({ error: 'Error retiring doctor: ' + error.message });
    }
};

const removeDoctor = async (req, res) => {
    const { adminId, doctorId } = req.body;

    try {
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
           
            return res.status(403).json({ message: 'Access denied. Only admins can remove doctors.' });
        }


        const doctor = await Doctor.findOneAndDelete({ user: doctorId });
        if (!doctor) {
            console.log(doctor.role);
            console.log(doctor);
            return res.status(404).json({ message: 'Doctor not found in the Doctor collection' });
        }
        const deletedUser = await User.findByIdAndDelete(doctorId);
        if (!deletedUser) {
            return res.status(404).json({ message: 'Doctor not found in the User collection' });
        }

        res.status(200).json({ message: 'Doctor removed successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error removing doctor: ' + error.message });
    }
};

const removePatient = async (req, res) => {
    const { adminId, patientId } = req.body;

    try {
        const requestingUser = await User.findById(adminId);

        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can remove patients.' });
        }

        const patient = await Patient.findOneAndDelete({ user: patientId });
        if (!patient) {
            return res.status(404).json({ message: 'Patient not found in the Patient collection' });
        }

        const deletedUser = await User.findByIdAndDelete(patientId);
        if (!deletedUser) {
            return res.status(404).json({ message: 'Patient not found in the User collection' });
        }

        res.status(200).json({ message: 'Patient removed successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error removing patient: ' + error.message });
    }
};



const getPatientById = async (req, res) => {
    const { adminId, patientId } = req.body;
    try {

        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can access patient details.' });
        }

        const patient = await User.findById(patientId);
        if (!patient || patient.role !== 'patient') {
            console.log(patient.role);
            return res.status(404).json({ message: 'Patient not found' });
        }

        res.status(200).json(patient);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching patient: ' + error.message });
    }
};



const getDoctorById = async (req, res) => {
    const { adminId, doctorId } = req.body;
    try {
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can access doctor details.' });
        }
        const doctor = await User.findById(doctorId);
        if (!doctor || doctor.role !== 'doctor') {
            console.log(doctor.role);
            return res.status(404).json({ message: 'Doctor not found' });
        }

        res.status(200).json(doctor); 
    } catch (error) {
        res.status(500).json({ error: 'Error fetching doctor: ' + error.message });
    }
};


const getAllDoctors = async (req, res) => {
    const { adminId } = req.body;
    try {
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can access doctor details.' });
        }

        const doctors = await User.find({ role: 'doctor' }).select('name email expertise isRetired phone specialty');
        res.status(200).json(doctors);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching doctors: ' + error.message });
    }
};

const getAllPatients = async (req, res) => {
    const { adminId } = req.body;
    try {
        const adminUser = await User.findById(adminId);
        if (!adminUser || adminUser.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can access patient details.' });
        }
        const patients = await User.find({ role: 'patient' }).select('name email phone age disease doctor ');
        res.status(200).json(patients);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching patients: ' + error.message });
    }
};

module.exports = {
    addDoctor,
    retireDoctor,
    removeDoctor,
    removePatient,
    getPatientById,
    getDoctorById,
    getAllDoctors,
    getAllPatients
};