const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

const UserModule = require('../models/user');
const Admin = UserModule.Admin;
const User = UserModule.User;
const Doctor = UserModule.Doctor;
const Patient = UserModule.Patient;

const signup = async (req, res) => {
    const { name, email, password, birthDate, gender, phone, role, age, expertise, specialty, disease, doctor } = req.body;

    // Basic validation for required fields
    if (!name || !email || !password || !birthDate || !gender || !phone || !role || !age) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        // Prevent creating an admin via this route
        if (role === 'admin') {
            return res.status(403).json({ message: 'Creating admin is not allowed via this route' });
        }

        // Check if the email already exists in any of the collections
        const existingUser = await User.findOne({ email });
        const existingPatient = await Patient.findOne({ email });
        const existingDoctor = await Doctor.findOne({ email });

        if (existingUser || existingPatient || existingDoctor) {
            return res.status(400).json({ message: 'User already exists' });
        }



        // If role is doctor, we need to check for expertise and specialty
        if (role === 'doctor') {
            if (!expertise || !specialty) {
                return res.status(400).json({ message: 'Expertise and Specialty are required for doctors' });
            }

            // Now, create the user and the doctor record
            const newUser = new User({
                name, email, password, birthDate, gender, phone, role, age
            });

            const savedUser = await newUser.save();  // Save the user first

            // Create the doctor record linked to the saved user
            const newDoctor = new Doctor({
                user: savedUser._id, // Link the doctor to the user
                expertise,
                specialty
            });

            await newDoctor.save();  // Save the doctor record

            return res.status(201).json({ message: 'Doctor Signup successful' });
        }

        // If role is patient, we need to check for disease
        if (role === 'patient') {
            if (!disease || disease.length === 0) {
                return res.status(400).json({ message: 'Disease(s) are required for patients' });
            }

            // Now, create the user and the patient record
            const newUser = new User({
                name, email, password, birthDate, gender, phone, role, age
            });

            const savedUser = await newUser.save();  // Save the user first

            // Create the patient record linked to the saved user
            const newPatient = new Patient({
                user: savedUser._id, // Link the patient to the user
                disease,
                doctor  // Optionally, if the patient has a doctor assigned
            });

            await newPatient.save();  // Save the patient record

            return res.status(201).json({ message: 'Patient Signup successful' });
        }

        // If role is invalid
        return res.status(400).json({ message: 'Invalid role' });

    } catch (error) {
        res.status(500).json({ error: 'Error during signup: ' + error.message });
    }
};




// const adminSignup = async (req, res) => {
//     try {
//         if (!req.user || !req.user.email) {
//             return res.status(401).json({ message: 'Unauthorized: Invalid or missing user data' });
//         }
//         const defaultAdminEmail = 'admin@example.com';
// if (req.user.email !== defaultAdminEmail) {
//     return res.status(403).json({ message: 'Only the default admin can perform this action' });
// }

//         const { name, email, password, birthDate, gender, phone, age , role } = req.body;

//         // Validation
//         if (!name || !email || !password || !birthDate || !gender || !phone || !age || !role ) {
//             return res.status(400).json({ message: 'All fields are required' });
//         }


//         const existingAdmin = await Admin.findOne({ email });
//         if (existingAdmin) return res.status(400).json({ message: 'Admin already exists' });
//         const newUser = new User({
//             name, email, password, birthDate, gender, phone, role:'admin', age
//         });

//         const savedUser = await newUser.save();
//         const newAdmin = new Admin({
//             user: savedUser._id,
//             isDefaultAdmin: false
//         });
//         await newAdmin.save();

//         res.status(201).json({ message: 'Admin created successfully' });
//     } catch (error) {
//         res.status(500).json({ error: 'Error creating admin: ' + error.message });
//         console.log(User);
//     }
// };


const login = async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).send('User not found');
        }

      
        const isPasswordValid = bcrypt.compareSync(password, user.password);
        if (isPasswordValid) {
            res.status(200).json({ user });
        } else {
            res.status(401).send('Incorrect password');
        }

    } catch (err) {
        console.error('Login error:', err);
        res.status(500).send('Internal server error');
    }
};

const logout = async (req, res) => {
  
    res.status(200).json({ message: 'Logout successful' });
};

module.exports = {
    login,
    signup,
 
    logout,
};
