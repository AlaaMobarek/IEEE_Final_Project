const express = require('express');
const router = express.Router();
const systController = require('../controllers/systController');
const verifyRole = require('../middleware/verifyRole');

// System routes - protected by authentication and 'admin'/system responsible role
router.get('/best-doctors', verifyRole(['Admin']), systController.getBestDoctors);
router.get('/feedback', verifyRole(['doctor' , 'admin']), systController.getFeedback);
router.post('/add-feedback', verifyRole(['Patient']), systController.addFeedback);
router.get('/get_about', verifyRole(['Admin']), systController.getAbout);
router.put('/update_about', verifyRole(['Admin']), systController.updateAbout);
router.post('/create_about', verifyRole(['Admin']), systController.createAbout);
router.post('/link-patient-to-doctor', verifyRole(['Admin']), systController.linkPatientToDoctor);

module.exports = router;