const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const verifyRole = require('../middleware/verifyRole');

// Add a new doctor
router.post('/addDoctor', verifyRole(['Admin']), adminController.addDoctor);

// Retire a doctor
router.put('/retireDoctor', verifyRole(['Admin']), adminController.retireDoctor);

// Remove a doctor
router.delete('/removeDoctor', verifyRole(['Admin']), adminController.removeDoctor);

// Remove a patient
router.delete('/removePatient', verifyRole(['Admin']), adminController.removePatient);

// Get a single patient by ID

router.get('/getPatientById', verifyRole(['Admin']), adminController.getPatientById);

// Get a single doctor by ID
router.get('/getDoctorById', verifyRole(['Admin']), adminController.getDoctorById);

// Get all doctors
router.get('/getAllDoctors', verifyRole(['Admin']), adminController.getAllDoctors);

// Get all patients
router.get('/getAllPatients', verifyRole(['Admin']), adminController.getAllPatients);

module.exports = router;