const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctorController');
const verifyRole = require('../middleware/verifyRole');

// Doctor routes 
router.put('/update-profile', verifyRole(['Doctor']), doctorController.updateDoctorProfile);
router.get('/patients', verifyRole(['Doctor']), doctorController.getAllPatientsForDoctor);
router.get('/patient/:patientId', verifyRole(['Doctor']), doctorController.getPatientById);

module.exports = router;