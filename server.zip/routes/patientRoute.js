const express = require('express');
const router = express.Router();
const patientController = require('../controllers/patientController');
const verifyRole = require('../middleware/verifyRole');


// Patient routes 
router.put('/update-profile',verifyRole(['Patient']),patientController.updatePatientInfo);
router.get('/doctors', verifyRole(['Patient']), patientController.getAllAvailableDoctors);
router.get('/doctor/:id', verifyRole(['Patient']), patientController.getDoctorById);
module.exports = router;
