const mongoose = require('mongoose');

const connectDB = async () => {
    mongoose.connect(`mongodb://${process.env.DB_HOST}:${process.env.DB_PORT}/EMBS_Backend`).then(
        () => {
            console.log('Connected to MongoDB');
        }
    ).catch(
        (error) => {
            console.log('Connection failed', error);
        }
    );
};

module.exports = connectDB;
