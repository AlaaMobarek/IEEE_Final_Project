const { User, Doctor, Patient, Admin } = require('../models/user');

const verifyRole = (roles = []) => {
  return async (req, res, next) => {
    try {
      // الحصول على userId من headers أو query أو params
      const userId = req.headers['user-id'] || req.query.userId || req.params.userId;

      if (!userId) {
        return res.status(400).json({ message: 'User ID is required' });
      }

      const user = await User.findById(userId);

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

    
      const userRole = user.role.toLowerCase();
      const allowedRoles = roles.map(role => role.toLowerCase()); 

      if (!allowedRoles.includes(userRole)) {
        console.log(user.role); 
        console.log(roles); 
        return res.status(403).json({ message: 'Access denied' });
      }

   
      req.user = user;
      next();
    } catch (error) {
      res.status(500).json({ error: 'Server error: ' + error.message });
    }
  };
};

module.exports = verifyRole;